# System Black — Mylloon

A native Valenced color-theme plugin port of Mylloon's legacy **System black theme**.

- **Plugin ID:** `mylloon.theme.system-black`
- **Version:** `1.0.0`
- **Original author:** Mylloon (`158260864623968257`)
- **Theme group:** Mylloon's Themes
- **Bases:** Dark, Darker, Midnight. Light is intentionally left to Discord's default colors, matching the legacy theme's dark-only intent.

## Porting notes

The legacy `PRIMARY_*` and `PLUM_*` names are not used as current Valenced raw-color names. Their documented surfaces have instead been mapped to current Discord semantic tokens. This preserves the intended black surfaces without sending obsolete token names to the new API.

The original spoiler colors are retained exactly:

- Hidden: `#1E1F22`
- Revealed: `#232428`

## Install

Add the repository's public `index.json` URL in Valenced under **Settings → Valenced → Plugins → repository settings → Add repository**. Then open **Settings → Valenced → Themes → Manage theme plugins**, browse the repository, and install **System Black (Mylloon)**. Pick it in the Colors selector.

## Development

The plugin uses the public `valenced.api.themes` API and registers during `preInit`, following the same API shape used by the Celestia 1.1.6 reference plugin.
