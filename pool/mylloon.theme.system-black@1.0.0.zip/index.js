(function (e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: 'Module' });

  const systemBlack = {
    // Legacy v1 surfaces
    BACKGROUND_BASE_LOWEST: '#000000',
    BACKGROUND_BASE_LOWER: '#000000',
    BACKGROUND_BASE_LOW: '#000000',
    BACKGROUND_ACCENT: '#08080A',
    CARD_BACKGROUND_DEFAULT: '#08080A',
    CHANNEL_BACKGROUND_DEFAULT: '#000000',
    CHANNELTEXTAREA_BACKGROUND: '#08080A',
    TAB_BAR_BACKGROUND: '#08080A',

    // Legacy v2 / mobile surfaces
    BACKGROUND_SURFACE_HIGH: '#08080A',
    BACKGROUND_SURFACE_HIGHEST: '#08080A',
    BACKGROUND_SECONDARY_ALT: '#08080A',
    CONTROL_SECONDARY_BACKGROUND_DEFAULT: '#08080A',
    CONTROL_SECONDARY_BACKGROUND_ACTIVE: '#08080A',
    MOBILE_SEARCHBAR_GRADIENT_BACKGROUND: '#08080A',
    STANDALONE_CHANNEL_CONTENT_BACKGROUND: '#000000',
    MOBILE_ACTIONSHEET_BACKGROUND: '#08080A',
    MODAL_BACKGROUND: '#08080A',

    // Original spoiler colours
    SPOILER_HIDDEN_BACKGROUND: '#1E1F22',
    SPOILER_REVEALED_BACKGROUND: '#232428',
  };

  return e.default = plugin({
    preInit({ themes }) {
      themes.registerGroup('mylloon', {
        name: "Mylloon's Themes",
        description: 'Classic themes by Mylloon, adapted for Valenced.',
      });

      themes.registerTheme('mylloon', 'system-black', {
        name: 'System Black',
        description: 'Pure-black surfaces with subtle near-black controls. Original legacy theme by Mylloon.',
        getColors: () => ({
          semantic: {
            dark: systemBlack,
            darker: systemBlack,
            midnight: systemBlack,
          },
        }),
      });
    },
  }), e;
})({});
